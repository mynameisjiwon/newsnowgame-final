import pygame  # 배경 snowbackground 게임 이름 snowthrowing 
import sys
import random

from time import sleep

BLACK = (0, 0, 0)

padwidth = 400
padHeight = 640

padWidth = 480 # 게임화면의 가로크기
padHeight = 640 # 게임화면의 세로크기

snowImage = ['snowl.png', 'snow2.png', 'snow3.png', 'snow4.png' ]

def writeScore (count) :

    global gamePad
    font = pygame.font.Font (None, 20)
    text = font.render(' 파괴한 눈덩이 수:' + str(count), True, (255, 255,255)) 
    gamePad.blit(text, (10,0))

def writePassed(count) :
    
    global gamePad
    font = pygame.font.Font (None, 20)
    text = font.render ('놓친 눈덩이 :' + str(count), True, (255,0,0)) 
    gamePad.blit(text, (360,0))

def drawObject(obj, x, y):
    
    global gamePad
    gamePad.blit(obj, (x, y))
    
def writeMessage(text):
    
    global gamePad, gameOverSound
    
    textfont = pygame.font.Font (None, 80)
    text = textfont.render (text, True, (255, 0, 0))
    
    textpos = text.get_rect ()
    textpos.center = (padWidth/2, padHeight/2)
   
    gamePad.blit(text, textpos)
 
    pygame.display.update() 
    
    pygame.mixer.music.stop()
    
    gameOverSound.play()
    
    sleep (2) 
    
    pygame.mixer.music.play(-1)
    
    runGame()    

def crash():
    global gamePad
    writeMessage('눈덩이 파괴!')

def gameOver():
    global gamePad
    writeMessage('게임 오버!')

def initGame():
    global gamePad, clock, background,snowman,branch,explosion,branchSound,gameOverSound,explosionSound 
    
    pygame.init ()
    gamePad = pygame.display.set_mode((padWidth, padHeight))
    
    pygame.display.set_caption('snowthrowing')
    
    background = pygame.image.load('snowbackground.png')
    
    snowman = pygame.image.load('snowman.png')
    
    branch = pygame. image.load('branch.png')
    
    explosion = pygame.image.load('explosion.png')# 폭발 그림
    
    pygame.mixer.music.load('branch.wav')
    pygame.mixer.music.play(-1)
    
    branchSound = pygame.mixer.Sound('branch.wav')
    # 나뭇가지 사운드
    
    gameOverSound = pygame.mixer.Sound('branch.wav')
    # 게임 오버 사운드
    
    explosionSound = pygame.mixer.Sound('branch.wav')
    # 눈덩이 폭발 사운드
    clock = pygame.time.Clock()
    
    
def runGame():
    global gamePad, clock, background,snowman, branch,explosion,destroysound
    
    snowmanSize = snowman.get_rect().size

    snowmanWidth = snowmanSize[0]
    
    snowmanHeight = snowmanSize[1]
    
    x = padwidth * 0.45
    
    y = padHeight * 0.9
    snowmanX = 0
        
    branchXY= []
    
    snow = pygame.image.load(random. choice(snowImage))
    
    snowSize = snow.get_rect().size
    snowWidth = snowSize[0]
    snowHeight = snowSize[1]
    
    destroysound = pygame.mixer.Sound('branch.wav')

    #눈 초기 위치 설정
    snowX = random.randrange(0, padwidth - snowWidth)
    snowY = 0
    snowSpeed = 2
    
    isShot = False
    
    shotCount = 0
    snowPassed = 0  
    
    onGame = False
    
    while not onGame:
        for event in pygame.event.get():
            
            if event.type in [pygame.QUIT]:
                pygame.quit()
                sys.exit()
            
            if event.type in [pygame.KEYDOWN]:
                
                if event.key == pygame.K_LEFT:
                    snowmanX -= 5
                    
                elif event.key == pygame.K_RIGHT: 
                    snowmanX += 5
                    
                elif event.key == pygame.K_SPACE: # 나뭇가지 발사
                    branchX = x + snowmanWidth/2
                    branchY = y - snowmanHeight
                    branchXY.append ([branchX,branchY])    
                    
            if event.type in [pygame.KEYUP]:
                
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    snowmanX = 0    
                       
                
        drawObject(background, 0, 0)
        
        x += snowmanX
        if x < 0:
            x = 0

        elif x > padWidth - snowmanWidth:
            x = padWidth - snowmanWidth
            
        if y < snowY + snowHeight:
            
            if (snowX > x and snowX < x + snowmanWidth) or \
                (snowX + snowWidth > x and snowX + snowWidth < x + snowmanWidth):
                crash()
        
        drawObject(snowman, x, y)
        
        if len(branchXY) != 0:

            for i, bxy in enumerate(branchXY): # 나뭇가지 요소에 대해 반복함
                
                bxy[1] -= 10 # 나뭇가지의 y좌표-10 (위로 이동)
                branchXY[i][1] = bxy[1]
                
                if bxy[1] < snowY:

                    if bxy[0] > snowX and bxy[0] < snowX + snowWidth:
                        branchXY.remove(bxy)
                        isShot = True
                        shotCount += 1
        
                if bxy[1] <= 0: # 나뭇가지가 화면 밖을 벗어나면

                     try:
                       branchXY.remove(bxy) # 나뭇가지 제거
                    
                     except:
                       pass
                   

        if len(branchXY) != 0:

            for bx, by in branchXY:
                drawObject(branch, bx, by)

        writeScore(shotCount)

        snowY += snowSpeed # 눈덩이 아래로 움직임

        if snowY > padHeight:
                # 새로운 눈덩이 (랜덤)
            snow = pygame.image.load(random. choice(snowImage))
            
            snowSize = snow.get_rect().size
            snowWidth = snowSize[0]
            snowHeight = snowSize[1]
            
            snowX = random. randrange (0, padwidth - snowWidth)
            
            snowY = 0
            
            snowPassed += 1
            
        if snowPassed == 3: 
            gameOver()    
            
        writePassed(snowPassed)    

        if isShot:
            drawObject(explosion, snowX, snowY) # 눈덩이 폭발 그리기
            destroySound.play()
            
            snow = pygame.image.load(random. choice (snowImage))
            snowSize = snow.get_rect().size
            snowWidth = snowSize[0]
            snowHeight = snowSize[1]
            
            snowX = random. randrange(0, padWidth - snowWidth)
            
            snowY = 0
            
            destroySound = pygame.mixer.Sound('branch.wav')
            
            isShot = False
            
        
            snowSpeed += 0.02

            if snowSpeed >= 10:
                snowSpeed = 10
        
        
        drawObject(snow, snowX,snowY) # 눈덩이 그리기
        
        pygame.display.update()
        

        clock.tick(60)


    pygame.quit()
    